import UIKit

var num1 = 340
var num2 = 225
var num3 = 50
var add = num1 + num2 + num3
var sub = num1 - num2 - num3
var mult = num1 * num2 * num3
var div = num1 / num2 / num3
print("\num1) + \(num2) + \(num3) = \(add)")
print("\num1) - \(num2) - \(num3) = \(add)")
print("\num1) * \(num2) * \(num3) = \(add)")
print("\num1) / \(num2) / \(num3) = \(add)")
